chrome.action.onClicked.addListener(function(tab) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['contentScript.js']
    });
  });
  
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === 'summarize') {
      // Implement summarization logic
      const summary = 'Generated summary of the page content.';
      sendResponse({ summary: summary });
    } else if (request.action === 'paraphrase') {
      // Implement paraphrasing logic
      const paraphrase = 'Paraphrased version of the page content.';
      sendResponse({ paraphrase: paraphrase });
    } else if (request.action === 'check_ai_content') {
      // Implement AI content detection logic
      const isAIContent = false; // Replace with actual AI content detection
      sendResponse({ is_ai_content: isAIContent });
    }
  });
  