document.addEventListener('DOMContentLoaded', function() {
  var summarizeBtn = document.getElementById('summarizeBtn');
  summarizeBtn.addEventListener('click', summarize);

  var paraphraseBtn = document.getElementById('paraphraseBtn');
  paraphraseBtn.addEventListener('click', paraphrase);

  var contentAnalysisBtn = document.getElementById('contentAnalysisBtn');
  contentAnalysisBtn.addEventListener('click', checkAIContent);
});

function summarize() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var tab = tabs[0];
    chrome.tabs.sendMessage(tab.id, { action: 'summarize' }, function(response) {
      displayResult(response.summary);
    });
  });
}

function paraphrase() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var tab = tabs[0];
    chrome.tabs.sendMessage(tab.id, { action: 'paraphrase' }, function(response) {
      displayResult(response.paraphrase);
    });
  });
}

function checkAIContent() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var tab = tabs[0];
    chrome.tabs.sendMessage(tab.id, { action: 'contentAnalysis' }, function(response) {
      displayResult(response.analysisResult);
    });
  });
}

function displayResult(result) {
  var resultContainer = document.getElementById('resultContainer');
  resultContainer.innerHTML = result;
}